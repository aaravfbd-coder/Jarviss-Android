package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import java.util.Locale
import java.util.Calendar

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var torchOn = false
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 56, 36, 36)
            setBackgroundColor(0xFF101722.toInt())
        }
        status = TextView(this).apply {
            text = "J.A.R.V.I.S. • Phone Companion\nReady. Tap Speak to give a command."
            textSize = 19f
            setTextColor(0xFFF4EBDD.toInt())
        }
        layout.addView(status)
        fun addButton(label: String, action: () -> Unit) {
            layout.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        addButton("Speak") { startListening() }
        addButton("Flashlight ON/OFF") { toggleTorch() }
        addButton("Open WhatsApp") { openApp("com.whatsapp") }
        addButton("Open Instagram") { openApp("com.instagram.android") }
        addButton("Set test alarm (1 minute)") { scheduleAlarm(60_000L, "JARVIS test alarm") }
        addButton("Open JARVIS Dashboard") {
            val i = Intent(this, DashboardActivity::class.java)
            startActivity(i)
        }
        setContentView(layout)
        requestNeededPermissions()
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 11)
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
            speak("JARVIS is ready.")
        }
    }

    private fun speak(text: String) {
        status.text = text
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.currentTimeMillis()}")
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available on this device.")
            return
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 11); return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        try { startActivityForResult(intent, 12) } catch (_: Exception) { speak("Voice input could not start.") }
    }

    @Deprecated("Legacy activity result used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 12 && resultCode == RESULT_OK) {
            val phrase = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            handleCommand(phrase)
        }
    }

    private fun handleCommand(raw: String) {
        val c = raw.lowercase(Locale.ROOT)
        when {
            "flashlight" in c && ("on" in c || "turn on" in c) -> { setTorch(true); speak("Flashlight on.") }
            "flashlight" in c && ("off" in c || "turn off" in c) -> { setTorch(false); speak("Flashlight off.") }
            "open whatsapp" in c -> { openApp("com.whatsapp"); speak("Opening WhatsApp.") }
            "open instagram" in c -> { openApp("com.instagram.android"); speak("Opening Instagram.") }
            c.startsWith("call ") -> {
                val query = raw.substringAfter("call ", "").trim()
                if (query.isNotBlank()) {
                    val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))
                    startActivity(i)
                    speak("Dialler opened. Select the contact and confirm the call.")
                } else speak("Please say the contact name.")
            }
            c.startsWith("research ") -> {
                val topic = raw.substringAfter("research ").trim()
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(topic))))
                speak("Opening web research for $topic.")
            }
            c.contains("set alarm") -> {
                val time = Regex("(\\d{1,2})[:.](\\d{2})").find(raw)
                if (time != null) {
                    val h = time.groupValues[1].toIntOrNull() ?: 7
                    val m = time.groupValues[2].toIntOrNull() ?: 0
                    val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS alarm")
                    startActivity(i); speak("Opening the system alarm confirmation.")
                } else speak("Please say the alarm time, for example set alarm 7:30.")
            }
            else -> speak("I heard: $raw. This command is not connected yet.")
        }
    }

    private fun openApp(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) startActivity(intent) else Toast.makeText(this, "App not installed", Toast.LENGTH_SHORT).show()
    }

    private fun toggleTorch() = setTorch(!torchOn)
    private fun setTorch(on: Boolean) {
        try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (cameraId == null) { speak("Flashlight is unavailable."); return }
            manager.setTorchMode(cameraId, on)
            torchOn = on
        } catch (e: Exception) { speak("Flashlight could not be controlled: ${e.message}") }
    }

    private fun scheduleAlarm(delay: Long, label: String) {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java).putExtra("label", label)
        val pi = PendingIntent.getBroadcast(this, 101, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            speak("Please enable Alarms and reminders permission in Settings.")
            startActivity(Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return
        }
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delay, pi)
        speak("Alarm scheduled.")
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}
